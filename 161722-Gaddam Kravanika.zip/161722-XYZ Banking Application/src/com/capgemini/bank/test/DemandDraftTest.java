package com.capgemini.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;




public class DemandDraftTest {
	
	 static DemandDraftDAO dao;
	    static DemandDraft demanddraft;
	    
	    
	    @BeforeClass
	    public static void initialize() {
	        dao = new DemandDraftDAO();
	        demanddraft = new DemandDraft();
	    }
	    
	    @Test
	    public void testAddDemandDraftDetails() throws DemandDraftException {

	        assertNotNull(dao.addDemandDraftDetails(demanddraft));
	    }
	    
	    @Ignore
	    @Test
	    public void testAddDemandDraftDetails1() throws DemandDraftException {
	        assertEquals(10002, dao.addDemandDraftDetails(demanddraft));
	    }
	    
	    @Test
	    public void testAddDemandDraftDetails2() throws DemandDraftException {
	    	
	    	
	    	demanddraft.setCustomer_name("Sachin Sharma");
	    	demanddraft.setPhone_number("8908908900");
	    	demanddraft.setDd_amount(78000);
	    	demanddraft.setIn_favor_of("Capgemini");
	    	demanddraft.setDd_description("Company");
	        assertTrue("Data Inserted successfully",
	                Integer.parseInt(dao.addDemandDraftDetails(demanddraft)) > 10001);

	    }


}
